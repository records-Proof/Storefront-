import express from "express";
import crypto from "crypto";
import { requireAuth } from "../auth/routes.js";
import { getDb } from "../../lib/db.js";

export const affiliatesRouter = express.Router();

function genCode(){
  return crypto.randomBytes(5).toString("hex").toUpperCase();
}

affiliatesRouter.post("/register", requireAuth, (req,res) => {
  const db = getDb();
  const existing = db.prepare("SELECT * FROM affiliates WHERE user_id=?").get(req.user.uid);
  if (existing) return res.json({ ok:true, affiliate: existing });

  const code = genCode();
  db.prepare("INSERT INTO affiliates (user_id,referral_code,commission_bps,total_earned_cents,created_at) VALUES (?,?,?,?,?)")
    .run(req.user.uid, code, 1000, 0, new Date().toISOString());

  const affiliate = db.prepare("SELECT * FROM affiliates WHERE user_id=?").get(req.user.uid);
  return res.json({ ok:true, affiliate });
});

affiliatesRouter.get("/me", requireAuth, (req,res) => {
  const db = getDb();
  const affiliate = db.prepare("SELECT * FROM affiliates WHERE user_id=?").get(req.user.uid);
  return res.json({ ok:true, affiliate });
});

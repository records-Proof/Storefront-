import express from "express";
import Stripe from "stripe";
import { getDb, logEvent } from "../../lib/db.js";

export const checkoutRouter = express.Router();

const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || "";
const stripe = new Stripe(STRIPE_SECRET_KEY, { apiVersion: "2024-06-20" });
const PUBLIC_URL = process.env.PUBLIC_URL || "http://127.0.0.1:8080";
const CURRENCY = (process.env.CURRENCY || "usd").toLowerCase();

checkoutRouter.post("/create-session", async (req,res) => {
  try{
    const { items, referral_code } = req.body || {};
    if (!Array.isArray(items) || items.length === 0) return res.status(400).json({ error:"Empty cart" });

    const db = getDb();
    const catalog = db.prepare("SELECT * FROM products WHERE id=?");

    const line_items = items.map(i => {
      const p = catalog.get(i.id);
      if (!p) throw new Error(`Unknown product id: ${i.id}`);
      const qty = Math.max(1, Math.min(99, Number(i.qty || 1)));
      return {
        quantity: qty,
        price_data: {
          currency: CURRENCY,
          unit_amount: p.price_cents,
          product_data: {
            name: p.title,
            description: p.description || "",
            metadata: { pid: p.id }
          }
        }
      };
    });

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items,
      success_url: `${PUBLIC_URL}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${PUBLIC_URL}/cancel.html`,
      allow_promotion_codes: true,
      metadata: {
        referral_code: referral_code || "",
        created_at: new Date().toISOString()
      }
    });

    logEvent("CHECKOUT_SESSION_CREATED", { session_id: session.id, referral_code: referral_code || "" });

    return res.json({ url: session.url });
  } catch(e){
    return res.status(500).json({ error: e.message || "Failed to create session" });
  }
});

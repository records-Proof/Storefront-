import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { getDb } from "../../lib/db.js";

export const authRouter = express.Router();

const JWT_SECRET = process.env.JWT_SECRET || "dev_secret";
const COOKIE_SECURE = String(process.env.COOKIE_SECURE || "0") === "1";

function sign(user){
  return jwt.sign({ uid: user.id, role: user.role, email: user.email }, JWT_SECRET, { expiresIn: "7d" });
}

export function requireAuth(req, res, next){
  try{
    const token = req.cookies?.session || (req.headers.authorization || "").replace(/^Bearer\s+/i,"");
    if (!token) return res.status(401).json({ error:"Not authenticated" });
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error:"Invalid session" });
  }
}

export function requireRole(role){
  return (req,res,next) => {
    if (!req.user) return res.status(401).json({ error:"Not authenticated" });
    if (req.user.role !== role) return res.status(403).json({ error:"Forbidden" });
    next();
  };
}

authRouter.post("/register", (req,res) => {
  const { email, password } = req.body || {};
  if (!email || !password || String(password).length < 8) return res.status(400).json({ error:"Invalid email/password" });

  const db = getDb();
  const existing = db.prepare("SELECT id FROM users WHERE email=?").get(email);
  if (existing) return res.status(409).json({ error:"Email already exists" });

  const hash = bcrypt.hashSync(password, 12);
  const info = db.prepare("INSERT INTO users (email,password_hash,role,created_at) VALUES (?,?,?,?)")
    .run(email, hash, "customer", new Date().toISOString());

  const user = { id: info.lastInsertRowid, email, role:"customer" };
  const token = sign(user);

  res.cookie("session", token, { httpOnly:true, sameSite:"lax", secure: COOKIE_SECURE, maxAge: 7*24*3600*1000 });
  return res.json({ ok:true, user:{ email, role:"customer" } });
});

authRouter.post("/login", (req,res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error:"Missing email/password" });

  const db = getDb();
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!user) return res.status(401).json({ error:"Invalid credentials" });

  const ok = bcrypt.compareSync(password, user.password_hash);
  if (!ok) return res.status(401).json({ error:"Invalid credentials" });

  const token = sign(user);
  res.cookie("session", token, { httpOnly:true, sameSite:"lax", secure: COOKIE_SECURE, maxAge: 7*24*3600*1000 });
  return res.json({ ok:true, user:{ email:user.email, role:user.role } });
});

authRouter.post("/logout", (req,res) => {
  res.clearCookie("session");
  return res.json({ ok:true });
});

authRouter.get("/me", requireAuth, (req,res) => {
  return res.json({ ok:true, user: req.user });
});

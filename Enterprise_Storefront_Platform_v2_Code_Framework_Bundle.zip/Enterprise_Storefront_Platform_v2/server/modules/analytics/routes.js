import express from "express";
import { getDb } from "../../lib/db.js";
import { requireAuth, requireRole } from "../auth/routes.js";

export const analyticsRouter = express.Router();

// admin-only KPIs
analyticsRouter.get("/kpi", requireAuth, requireRole("admin"), (req,res) => {
  const db = getDb();
  const revenue = db.prepare("SELECT COALESCE(SUM(amount_total_cents),0) as c FROM orders WHERE payment_status='paid'").get().c;
  const orders = db.prepare("SELECT COUNT(*) as c FROM orders WHERE payment_status='paid'").get().c;
  const customers = db.prepare("SELECT COUNT(*) as c FROM users WHERE role='customer'").get().c;
  return res.json({ revenue_cents: revenue, paid_orders: orders, customers });
});

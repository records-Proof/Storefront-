import express from "express";
import { getDb } from "../../lib/db.js";

export const productsRouter = express.Router();

productsRouter.get("/", (req,res) => {
  const db = getDb();
  const rows = db.prepare("SELECT id,title,description,price_cents,category,subcategory,badge FROM products ORDER BY created_at DESC").all();
  return res.json({ items: rows });
});

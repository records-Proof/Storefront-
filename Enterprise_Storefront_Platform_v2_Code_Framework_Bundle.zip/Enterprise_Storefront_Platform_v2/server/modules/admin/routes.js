import express from "express";
import { getDb } from "../../lib/db.js";
import { requireAuth, requireRole } from "../auth/routes.js";

export const adminRouter = express.Router();
adminRouter.use(requireAuth, requireRole("admin"));

adminRouter.get("/products", (req,res) => {
  const db = getDb();
  const items = db.prepare("SELECT * FROM products ORDER BY created_at DESC").all();
  res.json({ items });
});

adminRouter.post("/products", (req,res) => {
  const { id, title, description, price_cents, category, subcategory, badge, deliverable_file, download_url } = req.body || {};
  if (!id || !title || !Number.isInteger(price_cents)) return res.status(400).json({ error:"Missing fields" });
  const db = getDb();
  db.prepare(`INSERT OR REPLACE INTO products (id,title,description,price_cents,category,subcategory,badge,deliverable_file,download_url,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?)`)
    .run(id, title, description || "", price_cents, category||"", subcategory||"", badge||"", deliverable_file||null, download_url||null, new Date().toISOString());
  res.json({ ok:true });
});

adminRouter.get("/orders", (req,res) => {
  const db = getDb();
  const items = db.prepare("SELECT id,email,payment_status,amount_total_cents,currency,created_at FROM orders ORDER BY created_at DESC LIMIT 200").all();
  res.json({ items });
});

adminRouter.get("/licenses", (req,res) => {
  const db = getDb();
  const items = db.prepare("SELECT * FROM licenses ORDER BY issued_at DESC LIMIT 200").all();
  res.json({ items });
});

adminRouter.get("/users", (req,res) => {
  const db = getDb();
  const items = db.prepare("SELECT id,email,role,created_at FROM users ORDER BY created_at DESC LIMIT 200").all();
  res.json({ items });
});

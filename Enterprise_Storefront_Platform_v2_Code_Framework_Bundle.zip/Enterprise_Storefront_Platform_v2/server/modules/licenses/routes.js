import express from "express";
import { requireAuth } from "../auth/routes.js";
import { verifyLicense, activateLicense } from "./service.js";
import { getDb } from "../../lib/db.js";

export const licensesRouter = express.Router();

licensesRouter.get("/my", requireAuth, (req,res) => {
  const db = getDb();
  const rows = db.prepare("SELECT license_id,product_id,activation_count,max_activations,status,issued_at,expires_at FROM licenses WHERE owner_email=? ORDER BY issued_at DESC")
    .all(req.user.email);
  return res.json({ items: rows });
});

licensesRouter.post("/verify", (req,res) => {
  const { license_id } = req.body || {};
  if (!license_id) return res.status(400).json({ error:"Missing license_id" });
  const out = verifyLicense(license_id);
  if (!out.ok) return res.status(404).json(out);
  return res.json(out);
});

licensesRouter.post("/activate", (req,res) => {
  const { license_id } = req.body || {};
  if (!license_id) return res.status(400).json({ error:"Missing license_id" });
  const out = activateLicense(license_id);
  if (!out.ok) return res.status(400).json(out);
  return res.json(out);
});

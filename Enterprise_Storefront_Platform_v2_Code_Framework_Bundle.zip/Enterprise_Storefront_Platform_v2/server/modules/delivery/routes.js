import express from "express";
import path from "path";
import fs from "fs";
import Stripe from "stripe";
import { getDb } from "../../lib/db.js";
import { signDeliveryToken, verifyDeliveryToken, tokenTTLSeconds } from "../../lib/crypto.js";

export const deliveryRouter = express.Router();

const PUBLIC_URL = process.env.PUBLIC_URL || "http://127.0.0.1:8080";
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || "";
const stripe = new Stripe(STRIPE_SECRET_KEY, { apiVersion: "2024-06-20" });

const rootDir = path.resolve(process.cwd());
const deliverablesDir = path.join(rootDir, "deliverables");

deliveryRouter.get("/links/:sessionId", async (req,res) => {
  try{
    const sessionId = req.params.sessionId;
    const session = await stripe.checkout.sessions.retrieve(sessionId, { expand:["line_items"] });
    if (session.payment_status !== "paid") return res.status(403).json({ error:"Payment not completed." });

    const db = getDb();
    const catalog = db.prepare("SELECT * FROM products WHERE id=?");
    const exp = Math.floor(Date.now()/1000) + tokenTTLSeconds();

    const items = (session.line_items?.data || []).map(li => {
      const pid = li.price?.product?.metadata?.pid || null;
      const p = pid ? catalog.get(pid) : null;
      if (!p) return null;
      const token = signDeliveryToken({ sid: session.id, pid: p.id, exp });
      return { pid: p.id, title: p.title, qty: li.quantity || 1, link: `${PUBLIC_URL}/api/delivery/download/${token}` };
    }).filter(Boolean);

    return res.json({ session_id: session.id, expires_at: exp, items });
  } catch(e){
    return res.status(500).json({ error: e.message || "Failed to generate links" });
  }
});

deliveryRouter.get("/download/:token", async (req,res) => {
  try{
    const v = verifyDeliveryToken(req.params.token);
    if (!v.ok) return res.status(403).send(v.error);

    const { sid, pid } = v.payload;
    const session = await stripe.checkout.sessions.retrieve(sid);
    if (session.payment_status !== "paid") return res.status(403).send("Payment not completed.");

    const db = getDb();
    const p = db.prepare("SELECT * FROM products WHERE id=?").get(pid);
    if (!p) return res.status(404).send("Unknown product");

    if (p.deliverable_file){
      const filePath = path.join(deliverablesDir, p.deliverable_file);
      if (!fs.existsSync(filePath)) return res.status(404).send("Deliverable not found on server");
      return res.download(filePath, p.deliverable_file);
    }
    if (p.download_url){
      return res.redirect(302, p.download_url);
    }
    return res.status(404).send("No deliverable configured");
  } catch(e){
    return res.status(500).send("Download failed");
  }
});

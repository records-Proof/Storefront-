import express from "express";
import dotenv from "dotenv";
import cookieParser from "cookie-parser";
import rateLimit from "express-rate-limit";
import path from "path";
import fs from "fs";

dotenv.config();

import { initDb } from "./lib/db.js";
import { authRouter } from "./modules/auth/routes.js";
import { productsRouter } from "./modules/products/routes.js";
import { checkoutRouter } from "./modules/checkout/routes.js";
import { stripeWebhookRouter } from "./modules/stripe_webhook/routes.js";
import { deliveryRouter } from "./modules/delivery/routes.js";
import { licensesRouter } from "./modules/licenses/routes.js";
import { affiliatesRouter } from "./modules/affiliates/routes.js";
import { analyticsRouter } from "./modules/analytics/routes.js";
import { adminRouter } from "./modules/admin/routes.js";

const app = express();
const PORT = Number(process.env.PORT || 8080);
const PUBLIC_URL = process.env.PUBLIC_URL || `http://127.0.0.1:${PORT}`;

const rootDir = path.resolve(process.cwd());
const webDir = path.join(rootDir, "web");
const dataDir = path.join(rootDir, "data");
const deliverablesDir = path.join(rootDir, "deliverables");

fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(deliverablesDir, { recursive: true });

// global rate limit
app.use(rateLimit({
  windowMs: 60_000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false
}));

app.use(cookieParser());
app.use(express.json({ limit: "1mb" }));

// init database
initDb();

// API
app.use("/api/auth", authRouter);
app.use("/api/products", productsRouter);
app.use("/api/checkout", checkoutRouter);
app.use("/api/stripe", stripeWebhookRouter); // includes /webhook
app.use("/api/delivery", deliveryRouter);
app.use("/api/licenses", licensesRouter);
app.use("/api/affiliates", affiliatesRouter);
app.use("/api/analytics", analyticsRouter);
app.use("/api/admin", adminRouter);

// Health
app.get("/api/health", (req, res) => res.json({ ok: true, public_url: PUBLIC_URL }));

// Static
app.use(express.static(webDir));

app.listen(PORT, () => console.log(`Enterprise v2 server running at ${PUBLIC_URL}`));
